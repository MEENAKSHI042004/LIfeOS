from typing import Any

from apps.analytics.models import UserActivity
from apps.accounts.models import User


def log_user_activity(
    *,
    user: User,
    event_type: str,
    metadata: dict[str, Any]
) -> None:

    UserActivity.objects.create(
        user=user,
        event_type=event_type,
        metadata=metadata
    )