from django.urls import path
from .views import dashboard_view

from .views import DailyBriefingView

urlpatterns = [

    path(
        'daily-briefing/',
        DailyBriefingView.as_view()
    ),

    path(
        'dashboard/',
        dashboard_view
    ),
]