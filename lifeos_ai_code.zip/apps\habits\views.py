from rest_framework import generics, permissions
from .models import Habit, HabitLog
from .serializers import HabitSerializer, HabitLogSerializer

from services.activity_logger import log_user_activity
class HabitListCreateView(generics.ListCreateAPIView):

    serializer_class = HabitSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Habit.objects.filter(
            user=self.request.user
        )

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)
        class HabitCompleteView(generics.CreateAPIView):

    serializer_class = HabitLogSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):

        habit = serializer.validated_data['habit']

        serializer.save()

        # Increment streak
        habit.streak_count += 1
        habit.save()

        # Create behavioral event
        log_user_activity(
            user=self.request.user,
            event_type='habit_completed',
            metadata={
                'habit_name': habit.title,
                'frequency': habit.frequency,
                'streak_count': habit.streak_count,
            }
        )
