"""
apps/analytics/views.py
Feeds the premium dashboard template with all required context.
"""

from __future__ import annotations

import json
from datetime import date, timedelta
from typing import Any

from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.utils import timezone

from apps.accounts.models import User
from apps.finance.models import Transaction
from apps.goals.models import Goal, Milestone
from apps.habits.models import Habit, HabitLog
from apps.analytics.models import UserActivity
from services.ml_engine import (
    calculate_productivity_score,
    calculate_financial_health,
    calculate_habit_consistency,
    calculate_goal_completion,
)
from services.recommendation_engine import generate_daily_recommendation


@login_required
def dashboard(request) -> Any:
    user: User = request.user
    today = date.today()
    week_ago = today - timedelta(days=7)

    # ── Score Metrics ──────────────────────────────────────────────────────
    productivity_score: float = calculate_productivity_score(user)
    financial_health: float   = calculate_financial_health(user)
    habit_consistency: float  = calculate_habit_consistency(user)
    goal_completion: float    = calculate_goal_completion(user)

    # Week-over-week productivity delta
    prev_week_score: float = calculate_productivity_score(
        user, reference_date=today - timedelta(days=7)
    )
    productivity_delta: float = round(productivity_score - prev_week_score, 1)

    # ── Goal milestone counts ──────────────────────────────────────────────
    active_goals = (
        Goal.objects.filter(user=user, status="in_progress")
        .prefetch_related("milestones")
        .order_by("deadline")[:4]
    )
    total_milestones: int     = Milestone.objects.filter(goal__user=user).count()
    completed_milestones: int = Milestone.objects.filter(
        goal__user=user, is_completed=True
    ).count()

    # ── Expense chart data (last 7 days) ───────────────────────────────────
    expense_rows = (
        Transaction.objects
        .filter(user=user, date__gte=week_ago, date__lte=today)
        .order_by("date")
        .values("date", "amount")
    )

    # Build day-keyed totals so missing days show 0
    expense_by_day: dict[date, float] = {}
    for row in expense_rows:
        expense_by_day[row["date"]] = (
            expense_by_day.get(row["date"], 0) + float(row["amount"])
        )

    days_range = [today - timedelta(days=i) for i in range(6, -1, -1)]
    expense_labels: list[str]  = [d.strftime("%a") for d in days_range]
    expense_values: list[float] = [round(expense_by_day.get(d, 0), 2) for d in days_range]
    expense_total: str = f"{sum(expense_values):,.0f}"

    # ── Habit chart data (last 7 days) ─────────────────────────────────────
    total_habits: int = Habit.objects.filter(user=user, is_active=True).count()

    habit_values: list[float] = []
    for d in days_range:
        if total_habits == 0:
            habit_values.append(0.0)
            continue
        completed_on_day = HabitLog.objects.filter(
            habit__user=user,
            completed_date=d,
            is_completed=True,
        ).count()
        habit_values.append(round((completed_on_day / total_habits) * 100, 1))

    habit_labels: list[str] = expense_labels  # same day labels

    # ── Recent event log (today, latest 5) ────────────────────────────────
    recent_events = (
        UserActivity.objects
        .filter(user=user, timestamp__date=today)
        .order_by("-timestamp")[:5]
    )

    # ── AI Daily Briefing ─────────────────────────────────────────────────
    ai_briefing: str = generate_daily_recommendation(user)
    # Wrap key phrases in <strong> for the template
    highlight_words = [
        ("habit consistency", "habit consistency"),
        ("morning routine", "morning routine"),
        ("food delivery", "food delivery"),
    ]
    for phrase, _ in highlight_words:
        ai_briefing = ai_briefing.replace(phrase, f"<strong>{phrase}</strong>")
        ai_briefing = ai_briefing.replace(phrase.title(), f"<strong>{phrase.title()}</strong>")

    context: dict[str, Any] = {
        "today": today,

        # Scores
        "productivity_score":    round(productivity_score, 1),
        "productivity_delta":    productivity_delta,
        "financial_health":      round(financial_health, 2),
        "habit_consistency":     round(habit_consistency, 1),
        "goal_completion":       round(goal_completion, 2),

        # Milestone counts
        "total_milestones":      total_milestones,
        "completed_milestones":  completed_milestones,

        # Chart data — serialised for Chart.js <script>
        "expense_labels": json.dumps(expense_labels),
        "expense_values": json.dumps(expense_values),
        "expense_total":  expense_total,

        "habit_labels":  json.dumps(habit_labels),
        "habit_values":  json.dumps(habit_values),

        # Lists
        "active_goals":    active_goals,
        "recent_events":   recent_events,

        # AI
        "ai_briefing":    ai_briefing,
        "ai_confidence":  87,      # replace with real confidence from your ML engine
        "unread_alerts":  0,       # e.g. budget warning count
    }

    return render(request, "analytics/dashboard.html", context)