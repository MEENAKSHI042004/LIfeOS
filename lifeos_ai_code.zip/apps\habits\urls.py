from django.urls import path

from .views import (
    HabitListCreateView,
    HabitCompleteView
)

urlpatterns = [
    path(
        '',
        HabitListCreateView.as_view(),
        name='habit-list-create'
    ),

    path(
        'complete/',
        HabitCompleteView.as_view(),
        name='habit-complete'
    ),
]